package com.Students.Subject.Service;

import com.Students.Subject.Entity.Student;
import com.Students.Subject.Repository.StudentRepository;
import com.Students.Subject.Repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;

@Service
public class StudentService {
    private StudentRepository studentRepository;
    private SubjectRepository subjectRepository;

    @Autowired
    public StudentService(StudentRepository studentRepository, SubjectRepository subjectRepository) {
        this.studentRepository = studentRepository;
        this.subjectRepository = subjectRepository;
    }


    public void saveStudentDetails(Student student){
        studentRepository.save(student);
    }

    public List<Student> getDetails(){
    return studentRepository.findAll();

    }

    public List<Student> searchBySubjectName(String subjectName){
        return studentRepository.findBySubjectsSubjectContaining(subjectName);
    }

    public List<Student> searchByStudentName(String studentName){
        List<Student> dataBaseName = studentRepository.findByNameContaining(studentName);
        return dataBaseName;
    }

    public List<Student> searchStudentsByName(String testName) {
        return studentRepository.findByNameContaining(testName);
    }


//    public List<Student> getStudentNames(){
//        return studentRepository.
//    }

}
