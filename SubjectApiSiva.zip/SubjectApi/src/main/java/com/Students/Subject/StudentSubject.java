//package com.Students.Subject;
//
//import com.Students.Subject.Entity.Subject;
//import lombok.Getter;
//import lombok.Setter;
//
//import java.util.List;
//
//@Getter
//@Setter
//public class StudentSubject {
//    private String name;
//    private List<Subject> subjects;
//
//}
