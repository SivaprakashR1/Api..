package com.Students.Subject.Controller;


import com.Students.Subject.Entity.Student;
import com.Students.Subject.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Api")
public class StudentController {
    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    public StudentService studentService;

@GetMapping("/GetDetails")
    public List<Student> getStudentDetails(){
    return studentService.getDetails();

}
@GetMapping("/GetBySubject")
public ResponseEntity<List<Student>> searchBySubject(@RequestParam String subjectName){
    List<Student> students = studentService.searchBySubjectName(subjectName);
    return ResponseEntity.ok(students);
}

@GetMapping("/GetByStudent")
public ResponseEntity<List<Student>> searchByStudent(@RequestParam String studentName){
    List<Student> students = studentService.searchByStudentName(studentName);
    return ResponseEntity.ok(students);
}

@PostMapping("/PostDetails")
    public String SaveDetails(@RequestBody Student student){
    studentService.saveStudentDetails(student);
    return "Posted";
}
}
