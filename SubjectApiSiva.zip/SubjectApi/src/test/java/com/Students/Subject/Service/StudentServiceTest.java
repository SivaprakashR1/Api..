package com.Students.Subject.Service;

import com.Students.Subject.Entity.Student;
import com.Students.Subject.Repository.StudentRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

// StudentServiceTest.java

@SpringBootTest
class StudentServiceTest {

    @Autowired
    private StudentService studentService;

    @MockBean
    private StudentRepository studentRepository; // Mocking the repository

    @Test
    void testSearchByStudentName() {
        // Given
        String testName = "John Doe";
        List<Student> students = Arrays.asList(
                new Student(1L, "John Doe"),
                new Student(2L, "John Doe")
        );
        when(studentRepository.findByNameContaining(testName)).thenReturn(students);

        // When
        List<Student> foundStudents = studentService.searchStudentsByName(testName);

        // Then
        assertEquals(2, foundStudents.size());
    }
}
